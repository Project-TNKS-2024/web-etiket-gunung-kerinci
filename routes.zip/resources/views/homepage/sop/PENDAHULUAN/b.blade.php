<dt class="chapter-subheader" id="pendahuluan-b">B.&Tab;Maksud dan Tujuan</dt>
<dd class="chapter-content">
    <ol>
        <li>Maksud</li>
        <p>Maksud penyusunan SOP pendakian Gunung Kerinci di TNKS ini adalah sebagai salah satu upaya untuk meningkatkan
            pelayanan demi keselamatan, kenyamanan dan ketertiban pendaki serta menjaga kelestarian keanekaragaman
            hayati dan ekosistem Gunung Kerinci.
        </p>
        <li>Tujuan</li>
        <p>SOP Pendakian Gunung Kerinci di TNKS ini disusun sebagai pedoman atau aturan pelaksanaan/penyelenggaraan
            pendakian Gunung Kerinci.
        </p>
    </ol>
</dd>
