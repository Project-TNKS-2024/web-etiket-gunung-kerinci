<dt class="chapter-subheader" id="ketentuan-d">D. SANKSI</dt>
<dd class="chapter-content">
    <p>Sanksi dikenakan kepada Pendaki apabila melanggar ketentuan sebagai berikut : </p>
    <ol class="d-flex flex-column gap-2">
        <li>Bagi pendaki yang memasuki kawasan TNKS lebih dari pukul 15.00 WIB diwajib untuk menunggu di lokasi berkemah
            (camping) atau homestay terdekat sampai pukul 07.30 WIB;</li>
        <li>Bagi pendaki yang tidak membawa alat pendakian sesuai standar maka harus melengkapinya atau tidak diizinkan
            melakukan pendakian;</li>
        <li>Bagi yang melanggar aturan tersebut pada point A, B dan C, maka pendaki yang bersangkutan dan organisasinya
            akan masuk Daftar Hitam (BLACKLIST) dan tidak diperbolehkan untuk melakukan pendakian kembali ke Gunung
            Kerinci sampai batas waktu yang diberikan Balai Besar TNKS</li>
    </ol>
    <p>Bagi Para Pendaki yang melakukan perbuatan hukum yang melanggar Peraturan Perundang-undangan yang berlaku di
        Republik Indonesia, dilakukan tindakan sesuai dengan Peraturan Perundang-undangan Republik Indonesia serta
        sesuai dengan Kitab Undang-Undang Hukum Acara Indonesia.
    </p>

</dd>
