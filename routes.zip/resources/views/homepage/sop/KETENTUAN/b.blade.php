<dt class="chapter-subheader" id="ketentuan-b">B. Pendaki DIWAJIBKAN</dt>
<dd class="chapter-content ">
    <ol class="d-flex flex-column gap-2">
        <li>Berbadan sehat pada saat melakukan pendakian dengan menunjukkan Surat Keterangan Dokter (asli) pada pintu
            masuk dan pada saat mengurus Simaksi;</li>
        <li>Masuk jalur pendakian antara pukul 07.30 s/d 15.00 WIB dan mendaki pada jalur yang sudah ditentukan/ jalur
            resmi;</li>
        <li>Mematuhi semua rambu-rambu dan informasi keselamatan yang ada di sepanjang jalur pendakian;</li>
        <li>Melakukan evakuasi mandiri terhadap diri dan rekannya yang sakit sebelum mendapatkan bantuan dari petugas;
        </li>
        <li>Wajib menggunakan dan membawa jasa Pemandu/ Porter yang telah terdaftar di Balai Besar TNKS;</li>
        <li>Memakai dan membawa perlengkapan standar pendakian gunung serta perbekalan pendakian yang cukup;</li>
        <li>Mengisi form identitas diri dan isian barang bawaan yang menghasilkan sampah;</li>
        <li>Membawa trash bag kantong sampah dan membawa sampah bawaannya ke luar kawasan Taman Nasional;</li>
        <li>Memprioritaskan penanganan bagi wanita yang sedang menstruasi utamanya segera membawa turun korban tersebut
            apabila sudah menderita sakit;</li>
        <li>Membawa kelengkapan P3K standar, dan survival kit standar;</li>
        <li>Menjaga norma agama, norma susila dan kearifan lokal;</li>
        <li>Mengikuti jalur pendakian yang sudah ditetapkan Balai Besar TNKS.</li>
    </ol>

    <p>Petugas Balai Besar TNKS akan memeriksa barang bawaan, karcis dan SIMAKSI sebelum dan sesudah memasuki kawasan.
        Dalam rangka penangulangan sampah di Gunung Kerinci oleh para pendaki diwajibkan untuk meninggalkan salah satu
        identitas asli pribadi kepada petugas akan dikembalikan kepada pendaki apabila barang bawaan yang menghasilkan
        sampah dibawa kembali keluar TNKS.
    </p>
</dd>
