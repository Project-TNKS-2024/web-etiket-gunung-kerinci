@extends('etiket.in.template.index')
@section('css')
@endsection

@section('main')
<div class="card-body">
    <h5 class="mt-2 text-center fw-bold">HALAMAN TIDAK TERSEDIA</h5>
    <div>
        <p class="fw-bold text-center my-5">Periksa kembali alamat URL</p>
        <a class="btn btn-primary gk-bg-primary700 py-2 w-100" href="{{ route('homepage.beranda') }}">Kembali ke Beranda</a>
    </div>
</div>
@endsection

@section('js')
@endsection