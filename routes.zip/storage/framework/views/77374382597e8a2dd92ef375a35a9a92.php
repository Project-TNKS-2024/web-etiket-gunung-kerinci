<?php $__env->startSection('css'); ?>
    <style>
        .dashboard-sidebar.accessories {
            height: 141px;
        }

        .dashboard-sidebar {
            min-width: 338px;
            min-height: 500px;
        }


        @media (max-width: 768px) {
            .dashboard-sidebar {
                height: 500px;
            }
        }

        label.mandatory::after {
            content: " *";
            color: red;
        }

        .custom-dropdown-item {
            width: fit-content;
            /* Set your desired width here */
        }

        .border-secondary {
            border-color: var(--neutrals500)
        }
    </style>
    <?php echo $__env->yieldContent('sub-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <main class="container-fluid gk-bg-neutrals100 px-5" style="overflow: hidden">

        <div class="row mx-auto justify-content-center" style="min-height: 500px;">
            <div class="col-12 col-sm-12 col-md-3 dashboard-sidebar py-5" style="">
                <?php echo $__env->make('etiket.user.template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <?php echo $__env->yieldContent('sub-main'); ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="<?php echo e(asset('bootstrap-5.3.3-dist/js/bootstrap.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\gunung-kerinci\resources\views/etiket/user/template/index.blade.php ENDPATH**/ ?>