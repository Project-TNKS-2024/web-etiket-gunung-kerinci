<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
   <meta name="author" content="AdminKit">
   <meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

   <link rel="preconnect" href="https://fonts.gstatic.com">
   <link rel="shortcut icon" href="<?php echo e(asset('adminkit/img/icons/icon-48x48.png')); ?>" />

   <link rel="canonical" href="https://demo-basic.adminkit.io/" />

   <title>AdminKit Demo - Bootstrap 5 Admin Template</title>

   <link href="<?php echo e(asset('adminkit/css/app.css')); ?>" rel="stylesheet">
   <!-- <link rel="stylesheet" href="<?php echo e(asset('bootstrap-5.3.3-dist/css/bootstrap.min.css')); ?>"> -->
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">

   <?php echo $__env->yieldContent('css'); ?>

</head>

<body>

   <div class="wrapper">
      <?php echo $__env->make('etiket.template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="main">
         <?php echo $__env->make('etiket.template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

         <main class="content">
            <?php echo $__env->yieldContent('main'); ?>
         </main>

         <?php echo $__env->make('etiket.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </div>

   </div>



   <?php echo $__env->yieldContent('modal'); ?>

   <script src="<?php echo e(asset('adminkit/js/app.js')); ?>"></script>

   <?php echo $__env->yieldContent('js'); ?>

</body>

</html><?php /**PATH E:\laravel\gunung-kerinci\resources\views/etiket/template/index.blade.php ENDPATH**/ ?>