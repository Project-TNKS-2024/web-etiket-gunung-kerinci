<?php $__env->startSection('css'); ?>
    <style>
        .pdf-container {
            max-width: 700px;
            width: 100%;
        }

        .header-bg {
            position: relative;
            background: url("<?php echo e(asset('assets/img/title-header-bg.png')); ?>") no-repeat;
            background-size: cover;
            background-position: 50% 50%;
            color: white;
        }


        .header-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            /* Adjust the alpha value for the desired opacity */
            z-index: 1;
        }

        .header-content {
            position: relative;
            z-index: 2;
        }

        .border-between {
            border-top: 2px solid white;
            width: 50px;
            margin: 20px 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="product-device shadow-sm d-none d-md-block"></div>
    <div class="product-device product-device-2 shadow-sm d-none d-md-block"></div>

    <header class="header-bg text-white text-center py-3">
        <div class="container header-content">
            <h1 class="fw-semibold fs-5 lead">Standar Operasional Prosedur</h1>
            <div class="border-between m-auto d-block"></div>
            <p class="lead fs-6">Pendakian Gunung Kerinci Di Taman Nasional Kerinci Seblat</p>
        </div>
    </header>
    <div class="container mt-5">

        

        <div class="">
            <iframe src="<?php echo e(asset('assets/pdf/panduan-sop.pdf')); ?>"
                class="pdf-container m-auto d-block my-3 border border-1 border border-secondary rounded shadow"
                height="700px"></iframe>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\gunung-kerinci\resources\views/homepage/panduan/panduan.blade.php ENDPATH**/ ?>