<dt class="chapter-subheader" id="ketentuan-c">C. Setiap Pendaki DILARANG</dt>
<dd class="chapter-content">
    <ol class="d-flex flex-column gap-2">
        <li>Membawa Satwa dan tumbuhan dan bagian-bagiannya dari luar dan dari dalam kawasan TNKS;</li>
        <li>Mengambil, merusak, semua jenis tanaman dan bagian-bagiannya di dalam kawasan TNKS;</li>
        <li>Membunuh, melukai, mengambil satwa beserta bagian-bagiannya dari dalam kawasan TNKS;</li>
        <li>Memetik, memindahkan, memotong, menebang, mencabut tumbuhan di dalam kawasan TNKS;</li>
        <li>Membawa Senjata api, senjata tajam (Parang, Golok dan sejenisnya) kecuali pisau lipat, pisau saku/pisau
            kecil;</li>
        <li>Melakukan aktivitas yang menyebabkan kebakaran hutan di dalam kawasan TNKS;</li>
        <li>Membuang sampah di dalam kawasan TNKS;</li>
        <li>Mengganggu, memindahkan dan merusak fasilitas yang tersedia di dalam kawasan TNKS;</li>
        <li>Melakukan Vandalisme dalam kawasan TNKS;</li>
        <li>Melakukan pendakian antara jam 15.00 s/d 07.30 WIB;</li>
        <li>Mengganti identitas/pendaki pada SIMAKSI atau tidak sesuai dengan SIMAKSI;</li>
        <li>Menggunakan SIMAKSI pendakian untuk kegiatan Diklat pencinta alam/kegiatan orientasi pencinta alam;</li>
        <li>Buang Air Besar di aliran sungai/mata air dan di sepanjang jalur pendakian;</li>
        <li>Membawa dan menggunakan Narkotika dan obat-obatan Terlarang (<b>NARKOBA</b>), Miras dan bahan-bahan yang
            dilarang
            oleh undang-undang Republik Indonesia di dalam kawasan TNKS dan sekitarnya.</li>
    </ol>

</dd>
<?php /**PATH E:\laravel\gunung-kerinci\resources\views/homepage/sop/KETENTUAN/c.blade.php ENDPATH**/ ?>