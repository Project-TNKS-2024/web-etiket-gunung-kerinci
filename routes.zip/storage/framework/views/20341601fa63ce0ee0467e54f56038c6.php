<header class="header-bg text-white text-center py-3">
    <div class="container header-content">
        <h1 class="fw-semibold fs-5 lead"><?php echo e($title); ?></h1>
        <div class="border-between m-auto d-block"></div>
        <p class="lead fs-6"><?php echo e($caption); ?></p>
    </div>
</header>
<?php /**PATH E:\laravel\gunung-kerinci\resources\views/homepage/template/header.blade.php ENDPATH**/ ?>