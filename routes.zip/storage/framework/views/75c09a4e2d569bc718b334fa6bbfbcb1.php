<dt class="chapter-subheader" id="pendahuluan-c">C.&Tab;Ruang Lingkup</dt>
<dd class="chapter-content">
    <p>
        Ruang Lingkup SOP Pendakian Gunung Kerinci di TNKS ini meliputi arahan teknis, prosedur pendakian dan larangan
        serta
        sanksi.
    </p>
</dd>
<?php /**PATH E:\laravel\gunung-kerinci\resources\views/homepage/sop/PENDAHULUAN/c.blade.php ENDPATH**/ ?>