<?php $__env->startSection('css'); ?>
    <style>
        .sidebar {
            background-color: #f8f9fa;
            padding: 20px;
            height: 100vh;
        }

        .profile-image {
            width: 100px;
            height: 100px;
            background-color: #ddd;
            border-radius: 50%;
            margin-bottom: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 sidebar">
                <div class="text-center">
                    <div class="profile-image"></div>
                    <h4>Pendaki Handal</h4>
                    <p>pendakikerinci@gmail.com</p>
                </div>
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action">Profile</a>
                    <a href="#" class="list-group-item list-group-item-action">Riwayat Booking</a>
                    <a href="#" class="list-group-item list-group-item-action">Ubah Password</a>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card mt-4">
                    <div class="card-body">
                        <form>
                            <div class="mb-3">
                                <label for="jenisKewarganegaraan" class="form-label">Jenis Kewarganegaraan</label>
                                <div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="kewarganegaraan" id="wni"
                                            value="wni" checked>
                                        <label class="form-check-label" for="wni">Warga Negara Indonesia</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="kewarganegaraan" id="wna"
                                            value="wna">
                                        <label class="form-check-label" for="wna">Warga Negara Asing</label>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="jenisIdentitas" class="form-label">Jenis Identitas</label>
                                <select class="form-select" id="jenisIdentitas">
                                    <option value="ktp">KTP</option>
                                    <option value="sim">SIM</option>
                                    <option value="passport">Passport</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="namaLengkap" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control" id="namaLengkap" required>
                            </div>
                            <div class="mb-3">
                                <label for="nikPassport" class="form-label">NIK/Passport</label>
                                <input type="text" class="form-control" id="nikPassport" required>
                            </div>
                            <div class="mb-3">
                                <label for="lampiranIdentitas" class="form-label">Lampiran Identitas</label>
                                <input type="file" class="form-control" id="lampiranIdentitas" required>
                            </div>
                            <div class="mb-3">
                                <label for="nomorTelepon" class="form-label">Nomor Telepon</label>
                                <input type="tel" class="form-control" id="nomorTelepon" required>
                            </div>
                            <div class="mb-3">
                                <label for="nomorTeleponDarurat" class="form-label">Nomor Telepon Darurat</label>
                                <input type="tel" class="form-control" id="nomorTeleponDarurat" required>
                            </div>
                            <div class="mb-3">
                                <label for="tanggalLahir" class="form-label">Tanggal Lahir</label>
                                <input type="date" class="form-control" id="tanggalLahir" required>
                            </div>
                            <div class="mb-3">
                                <label for="usia" class="form-label">Usia</label>
                                <input type="number" class="form-control" id="usia" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="beratBadan" class="form-label">Berat Badan</label>
                                    <input type="number" class="form-control" id="beratBadan" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="tinggiBadan" class="form-label">Tinggi Badan</label>
                                    <input type="number" class="form-control" id="tinggiBadan" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="alamatDomisili" class="form-label">Alamat Domisili</label>
                                <input type="text" class="form-control" id="alamatDomisili" required>
                            </div>
                            <div class="mb-3">
                                <label for="provinsi" class="form-label">Provinsi</label>
                                <select class="form-select" id="provinsi" required>
                                    <option value="">Pilih Provinsi</option>
                                    <option value="jakarta">Jakarta</option>
                                    <option value="jawa_barat">Jawa Barat</option>
                                    <option value="jawa_tengah">Jawa Tengah</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="kabupatenKota" class="form-label">Kabupaten/Kota</label>
                                <select class="form-select" id="kabupatenKota" required>
                                    <option value="">Pilih Kabupaten/Kota</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="kecamatan" class="form-label">Kecamatan</label>
                                <select class="form-select" id="kecamatan" required>
                                    <option value="">Pilih Kecamatan</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="desaKelurahan" class="form-label">Desa/Kelurahan</label>
                                <select class="form-select" id="desaKelurahan" required>
                                    <option value="">Pilih Desa/Kelurahan</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\gunung-kerinci\resources\views/sampel/tes2.blade.php ENDPATH**/ ?>