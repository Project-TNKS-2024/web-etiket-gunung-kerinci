<div class="d-none d-md-block" style="margin: 100px 0;">
    <div class="guide-container guide-card-border-b mx-auto">
        <?php for($i = 0; $i < count($panduan); $i++): ?> <?php if($i % 2==0): ?> <div class="d-flex flex-column align-items-center guide-right">
            <div class="guide-card card shadow-sm">
                <header class="fw-bold"><span>#<?php echo e($i + 1); ?></span> <?php echo e($panduan[$i]['title']); ?></header>
                <main><?php echo e($panduan[$i]['caption']); ?></main>
            </div>
            <div class="guide-card-tail"></div>
            <div class="guide-card-div"></div>
    </div>
    <?php endif; ?>
    <?php endfor; ?>
</div>

<div class="guide-container guide-card-border-t mx-auto" style="margin-left: 0px;">
    <?php for($i = 0; $i < count($panduan); $i++): ?> <?php if($i % 2==0): ?> <div class="d-flex flex-column align-items-center guide-left">
        <div class="guide-card-head"></div>
        <div class="guide-card card shadow-sm">
            <header class="fw-bold"><span>#<?php echo e($i + 2); ?></span> <?php echo e($panduan[$i + 1]['title']); ?>

            </header>
            <main><?php echo e($panduan[$i + 1]['caption']); ?></main>
        </div>
        <div class="guide-card-div"></div>
</div>
<?php endif; ?>
<?php endfor; ?>
</div>
</div>

<div class="d-flex d-md-none flex-column w-100 align-items-center" style="margin: 10px 0">
    <div class="guide-container guide-card-border-t" style="margin-left: 0px;">
        <?php for($i = 0; $i < count($panduan); $i++): ?> <div class="d-flex flex-column align-items-center ">
            <div class="guide-card-head"></div>
            <div class="guide-card card shadow-sm">
                <header class="fw-bold"><span>#<?php echo e($i + 1); ?></span> <?php echo e($panduan[$i]['title']); ?>

                </header>
                <main><?php echo e($panduan[$i]['caption']); ?></main>
            </div>
            <div class="guide-card-div"></div>
    </div>
    <?php endfor; ?>
</div>
</div><?php /**PATH E:\laravel\gunung-kerinci\resources\views/homepage/panduan/stepper.blade.php ENDPATH**/ ?>