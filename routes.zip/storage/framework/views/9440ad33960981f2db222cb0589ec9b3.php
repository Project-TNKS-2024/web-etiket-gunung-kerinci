<?php $__currentLoopData = $navlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="nav-item">
        <a href="<?php echo e($nav['link']); ?>" id="navigasi<?php echo e($loop->index); ?>" class="nav-link text-white py-0 rounded-lg"
            style="cursor: pointer; font-size: 14px;" aria-current="page"
            onclick="navigate(event,`<?php echo e($nav['link']); ?>`, `navigasi<?php echo e($loop->index); ?>`)"><?php echo e($nav['name']); ?></a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    function navigate(e, link, id) {}

    const navItems = document.querySelectorAll(".nav-link");
    for (let i = 0; i < navItems.length; i++) {
        if (window.location.href !== navItems[i].href) {
            navItems[i].classList.remove('gk-bg-base-white');
            navItems[i].classList.remove('gk-text-primary700');
            navItems[i].classList.remove('font-semibold');
            navItems[i].classList.add('text-white');
        } else {
            navItems[i].classList.add('gk-bg-base-white');
            navItems[i].classList.add('gk-text-primary700');
            navItems[i].classList.add('font-semibold');
            navItems[i].classList.remove('text-white');
        }
    }
</script>
<?php /**PATH E:\laravel\gunung-kerinci\resources\views/homepage/template/navbar-list.blade.php ENDPATH**/ ?>