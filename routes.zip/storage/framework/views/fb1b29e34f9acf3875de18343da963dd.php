<!doctype html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta name="description" content="">
   <meta name="author" content="">
   <title><?php echo e(config('app.name', 'Laravel')); ?></title>
   <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/logo/logo bulat.png')); ?>" />
   <link rel="stylesheet" href="<?php echo e(asset('modernize/css/styles.css')); ?>" />
   <style>
      .logo-img {
         text-decoration: none;
         color: black;
         font-weight: bold;
         font-size: 20px;
         font-family: sans-serif;
      }

      .logo-img img {
         width: 40px;
         margin-right: 5px;
      }
   </style>
   <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
   <!--  Body Wrapper -->
   <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full" data-sidebar-position="fixed" data-header-position="fixed">
      <!-- ========================================= -->
      <?php echo $__env->make('etiket.admin.template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!--  Main wrapper -->
      <div class="body-wrapper">
         <!--  Header Start -->
         <!-- ================================================ -->
         <?php echo $__env->make('etiket.admin.template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!--  Header End -->
         <div class="container-fluid" style="background-color: #f3f3f3;">
            <!--  Row 1 -->
            <?php echo $__env->yieldContent('main'); ?>


            <!-- footer  -->
            <!-- ============================================== -->
            <?php echo $__env->make('etiket.admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
      </div>
   </div>
   <script src="<?php echo e(asset('modernize/libs/jquery/dist/jquery.min.js')); ?>"></script>
   <script src="<?php echo e(asset('modernize/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>

   <script src="<?php echo e(asset('modernize/js/sidebarmenu.js')); ?>"></script>
   <script src="<?php echo e(asset('modernize/js/app.min.js')); ?>"></script>

   <script src="<?php echo e(asset('modernize/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
   <script src="<?php echo e(asset('modernize/libs/simplebar/dist/simplebar.js')); ?>"></script>
   <script src="<?php echo e(asset('modernize/js/dashboard.js')); ?>"></script>

   <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH E:\laravel\gunung-kerinci\resources\views/etiket/admin/template/index.blade.php ENDPATH**/ ?>