<?php $__env->startSection('css'); ?>
    <style>
        .reset-form {
            max-width: 540px;
            padding: 40px 0;
            width: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="position-fixed w-screen h-screen d-flex justify-content-center align-items-center" style="left:0; top:0;">
        <div class="text-xl font-semibold">404 | NOT FOUND</div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('etiket.in.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\gunung-kerinci\resources\views/errors/abort.blade.php ENDPATH**/ ?>