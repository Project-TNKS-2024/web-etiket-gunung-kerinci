## Project Progress

### Page
- **Beranda** ![50%](https://progress-bar.dev/50) **[Tinggal Integrasi dengan DB]**
  - Integration with weather data: belum
  - Integration with destination data: sudah
  - Integration with TNKS exploration data: belum
    
- **SOP** ![100%](https://progress-bar.dev/100)
- **Panduan** ![100%](https://progress-bar.dev/100)
- **Booking Online** ![50%](https://progress-bar.dev/50) **[Tinggal Integrasi dengan DB]**

#### ![70%](https://progress-bar.dev/70) Dashboard 
- **Profile** ![70%](https://progress-bar.dev/70) **[Tinggal Integrasi dengan DB]**
  - [x] Wilayah Indonesia
  - [x] Bendera untuk nomor telepon
- **Riwayat Booking** ![70%](https://progress-bar.dev/70) **[Tinggal Integrasi dengan DB]**
- **Ganti Password** ![70%](https://progress-bar.dev/70) **[Tinggal Integrasi dengan DB]**
- **Footer** ![0%](https://progress-bar.dev/0) **[Tinggal Integrasi dengan DB]**

### Admin
- **Admin** ![10%](https://progress-bar.dev/10) - Template Done
